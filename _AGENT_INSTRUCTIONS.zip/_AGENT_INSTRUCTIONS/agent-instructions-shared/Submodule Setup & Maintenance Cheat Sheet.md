
# Submodule Setup & Maintenance Cheat Sheet

This guide explains how to correctly add, update, and maintain your shared `_AGENT_INSTRUCTIONS/agent-instructions-shared` Git submodule.

---

## 1️⃣ Initial Setup

### A. Create your main project
```bash
cd my_flutter_project
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<you>/<my_flutter_project>.git
git push -u origin main
```

### B. Add the shared submodule
Let Git create the folder automatically:

```bash
git submodule add https://github.com/<you>/agent-instructions.git _AGENT_INSTRUCTIONS/agent-instructions-shared
git commit -m "Add shared agent-instructions submodule"
git push
```

> ✅ Git now creates `_AGENT_INSTRUCTIONS/agent-instructions-shared/` and updates `.gitmodules` automatically.

### C. Move starter files into the submodule
Once the folder exists, move your starter content into it and commit **within the submodule**:

```bash
mv ~/Downloads/agent-instructions-shared-starter/* _AGENT_INSTRUCTIONS/agent-instructions-shared/
cd _AGENT_INSTRUCTIONS/agent-instructions-shared
git add .
git commit -m "Import starter shared agent instructions"
git push origin main
cd ../../..
```

---

## 2️⃣ Adding project-specific instructions

Your local project notes live here:
```
_AGENT_INSTRUCTIONS/agent-per-project/
```
These stay in your main repo only and are never pushed to the shared repo.

```bash
mkdir -p _AGENT_INSTRUCTIONS/agent-per-project
git add _AGENT_INSTRUCTIONS/agent-per-project
git commit -m "Add per-project agent folder"
git push
```

---

## 3️⃣ Cloning the project later

Clone the main repo **with** submodules:

```bash
git clone --recursive https://github.com/<you>/<my_flutter_project>.git
```

If you forgot `--recursive`:
```bash
git submodule update --init --recursive
```

---

## 4️⃣ Pulling updates from the shared repo

When you make changes in `agent-instructions-shared` and push them upstream, update all projects like this:

```bash
cd _AGENT_INSTRUCTIONS/agent-instructions-shared
git pull origin main
cd ../../..
git add _AGENT_INSTRUCTIONS/agent-instructions-shared
git commit -m "Update shared agent instructions submodule"
git push
```

---

## 5️⃣ Replacing or resetting the submodule

If the submodule gets out of sync or you want to switch URLs:

```bash
git submodule deinit -f _AGENT_INSTRUCTIONS/agent-instructions-shared
rm -rf .git/modules/_AGENT_INSTRUCTIONS/agent-instructions-shared
git rm -f _AGENT_INSTRUCTIONS/agent-instructions-shared
git submodule add https://github.com/<you>/agent-instructions.git _AGENT_INSTRUCTIONS/agent-instructions-shared
git commit -m "Reinitialize agent-instructions submodule"
```

---

## 6️⃣ Quick Reference

| Action | Command |
|--------|----------|
| Add submodule | `git submodule add <url> <path>` |
| Init + clone submodules | `git clone --recursive <url>` |
| Update submodules | `git submodule update --remote --merge` |
| Remove submodule | See section 5️⃣ |
| Push changes (main repo) | `git add . && git commit -m "..." && git push` |
| Push changes (submodule) | `cd submodule && git add . && git commit -m "..." && git push` |

---

**Tip:** Run `git status` often — it will tell you when you’re inside the submodule vs. the main repo.

---

© 2025 Rob Campbell — internal agent instructions workflow
