# Submodule Daily Update Checklist

Use this flow whenever you open a project that embeds the `agent-instructions-shared` submodule and you know someone pushed new material to the shared repo. If you prefer automation, run the `shared-repo-update` script (details below).

## 1. Start in the main project root

```bash
cd /path/to/your/project
git status
```

Confirm the working tree is clean before touching the submodule. If you have local edits, stash or commit them first.

## 2. Enter the submodule and pull upstream changes

```bash
cd _AGENT_INSTRUCTIONS/agent-instructions-shared
git status
git fetch origin
git pull origin main
```

`git status` verifies you are on `main` with no pending work. `git pull` brings in the latest content from `https://github.com/bigbenchrob/agent-instructions.git`.

## 3. Return to the parent repo and record the new pointer

```bash
cd ../..
git status --short
git add _AGENT_INSTRUCTIONS/agent-instructions-shared
```

The status output should now show the submodule as modified. Adding it stages the updated commit hash in the parent repository.

## 4. Commit and push the parent repo

```bash
git commit -m "Update shared agent instructions"
git push
```

This saves the new submodule pointer and shares it with teammates.

## 5. Verify everything is clean

```bash
git status
```

You should see a clean working tree and your branch up to date with `origin/main`.

---

**Automation shortcut**

- Handle: `shared-repo-update`
- Script: `_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-update.sh`
- Usage (from project root):

  ```bash
  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-update.sh "Update shared agent instructions"
  ```

The script auto-publishes any pending edits in the submodule (via `shared-repo-publish`), enforces clean working trees, pulls the latest shared content, stages the submodule pointer, commits (using the message you provide or a default), and pushes the parent repository.

- Handle: `shared-repo-sync`
- Script: `_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-sync.sh`
- Usage (from project root):

  ```bash
  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-sync.sh "Sync shared agent instructions"
  ```

Runs the read-only half of the workflow: fetches/pulls the latest shared instructions, stages the submodule pointer, commits the parent repo, and pushes, assuming no new local edits exist in the submodule.

- Handle: `shared-repo-publish`
- Script: `_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-publish.sh`
- Usage (from project root or submodule):

  ```bash
  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-publish.sh "Refine shared instructions"
  ```

Use this if you only need to commit and push submodule changes without updating the parent repository pointer.

- Handle: `cli-command-menu`
- Script: `_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/cli-command-menu.sh`
- Usage (from project root):

  ```bash
  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/cli-command-menu.sh
  ```

Prints a quick reference of the automation commands and confirms whether the git aliases are installed.

- Handle: `shared-repo-register-aliases`
- Script: `_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-register-aliases.sh`
- Usage (from project root):

  ```bash
  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-register-aliases.sh
  ```

Run once per clone to expose the shortcuts as `git shared-repo-update`, `git shared-repo-sync`, and `git shared-repo-publish`.

---

**Troubleshooting tips**

- _Untracked files block the pull?_ Run `git clean -fd` inside the submodule (after backing up anything important) to remove stray files, then pull again.
- _Need to inspect the pulled changes?_ While inside the submodule, run `git log --oneline --max-count=5` or `git diff HEAD@{1}` before leaving.
- _Accidentally committed inside the submodule?_ Push those commits if they belong upstream, or reset with `git reset --hard origin/main` if they were stray.

Keep this checklist nearby for quick refreshers whenever the shared instructions receive updates elsewhere.
