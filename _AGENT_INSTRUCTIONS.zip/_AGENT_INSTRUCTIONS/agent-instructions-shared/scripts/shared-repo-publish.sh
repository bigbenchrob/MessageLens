#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUBMODULE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
DEFAULT_MESSAGE="Update shared agent instructions"
COMMIT_MESSAGE="${1:-$DEFAULT_MESSAGE}"

cd "${SUBMODULE_DIR}"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "[shared-repo-publish] Error: submodule directory is not a Git repository." >&2
  exit 1
fi

BRANCH_NAME="$(git rev-parse --abbrev-ref HEAD)"
if [[ "${BRANCH_NAME}" != "main" ]]; then
  echo "[shared-repo-publish] Warning: publishing from branch '${BRANCH_NAME}'." >&2
fi

if [[ -z "$(git status --porcelain)" ]]; then
  echo "[shared-repo-publish] No changes to publish."
  exit 0
fi

echo "[shared-repo-publish] Staging submodule changes..."
git add -A

echo "[shared-repo-publish] Committing with message: ${COMMIT_MESSAGE}"
git commit -m "${COMMIT_MESSAGE}"

echo "[shared-repo-publish] Pushing submodule branch ${BRANCH_NAME}..."
git push

echo "[shared-repo-publish] Done."
