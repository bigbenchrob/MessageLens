#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUBMODULE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${SUBMODULE_DIR}/../.." && pwd)"
DEFAULT_MESSAGE="Sync shared agent instructions"
COMMIT_MESSAGE="${1:-$DEFAULT_MESSAGE}"

cd "${REPO_ROOT}"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "[shared-repo-sync] Error: not inside a Git repository." >&2
  exit 1
fi

if [[ "$(git rev-parse --show-toplevel)" != "${REPO_ROOT}" ]]; then
  echo "[shared-repo-sync] Error: please run the script from the project root." >&2
  exit 1
fi

if ! git diff --quiet --ignore-submodules || ! git diff --cached --quiet --ignore-submodules; then
  echo "[shared-repo-sync] Error: parent repo has uncommitted changes. Commit or stash them before running." >&2
  exit 1
fi

if [[ -n "$(git -C "${SUBMODULE_DIR}" status --porcelain)" ]]; then
  echo "[shared-repo-sync] Error: submodule contains local changes. Publish or discard them first." >&2
  exit 1
fi

echo "[shared-repo-sync] Pulling latest shared instructions..."
git -C "${SUBMODULE_DIR}" fetch origin
git -C "${SUBMODULE_DIR}" pull --ff-only origin main

echo "[shared-repo-sync] Staging submodule pointer..."
git add "${SUBMODULE_DIR}"

if git diff --cached --quiet; then
  echo "[shared-repo-sync] Submodule already up to date. No commit needed."
  exit 0
fi

echo "[shared-repo-sync] Committing with message: ${COMMIT_MESSAGE}"
git commit -m "${COMMIT_MESSAGE}"

echo "[shared-repo-sync] Pushing parent repository..."
git push

echo "[shared-repo-sync] Done."
