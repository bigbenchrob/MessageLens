#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUBMODULE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${SUBMODULE_DIR}/../.." && pwd)"
DEFAULT_MESSAGE="Update shared agent instructions"
COMMIT_MESSAGE="${1:-$DEFAULT_MESSAGE}"
PUBLISH_SCRIPT="${SCRIPT_DIR}/shared-repo-publish.sh"
SYNC_SCRIPT="${SCRIPT_DIR}/shared-repo-sync.sh"

cd "${REPO_ROOT}"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "[shared-repo-update] Error: not inside a Git repository." >&2
  exit 1
fi

if [[ "$(git rev-parse --show-toplevel)" != "${REPO_ROOT}" ]]; then
  echo "[shared-repo-update] Error: please run the script from the project root." >&2
  exit 1
fi

if ! git diff --quiet --ignore-submodules || ! git diff --cached --quiet --ignore-submodules; then
  echo "[shared-repo-update] Error: parent repo has uncommitted changes. Commit or stash them before running." >&2
  exit 1
fi

if [[ -n "$(git -C "${SUBMODULE_DIR}" status --porcelain)" ]]; then
  if [[ ! -x "${PUBLISH_SCRIPT}" ]]; then
    echo "[shared-repo-update] Error: submodule has local changes and publish helper is missing or not executable." >&2
    exit 1
  fi

  echo "[shared-repo-update] Submodule has local changes. Publishing them now..."
  "${PUBLISH_SCRIPT}" "${COMMIT_MESSAGE}"
fi

if [[ -n "$(git -C "${SUBMODULE_DIR}" status --porcelain)" ]]; then
  echo "[shared-repo-update] Error: submodule still has local changes after attempting to publish." >&2
  exit 1
fi

if [[ ! -x "${SYNC_SCRIPT}" ]]; then
  echo "[shared-repo-update] Error: sync helper is missing or not executable." >&2
  exit 1
fi

exec "${SYNC_SCRIPT}" "${COMMIT_MESSAGE}"
