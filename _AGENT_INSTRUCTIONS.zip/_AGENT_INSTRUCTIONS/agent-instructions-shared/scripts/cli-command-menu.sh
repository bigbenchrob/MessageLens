#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUBMODULE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${SUBMODULE_DIR}/../.." && pwd)"

cd "${REPO_ROOT}"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "[cli-command-menu] Error: not inside a Git repository." >&2
  exit 1
fi

if [[ "$(git rev-parse --show-toplevel)" != "${REPO_ROOT}" ]]; then
  echo "[cli-command-menu] Error: please run the command from the project root." >&2
  exit 1
fi

has_alias() {
  git config --get "alias.$1" >/dev/null 2>&1
}

printf '%s\n\n' "Available automation commands:"

printf '%s\n' "Submodule maintenance"
if has_alias "shared-repo-update"; then
  printf '%s\n' "  git shared-repo-update \"<message>\"   # publish submodule edits, pull, stage pointer, commit, push"
else
  printf '%s\n' "  git shared-repo-update \"<message>\"   # (alias not registered)"
fi
if has_alias "shared-repo-sync"; then
  printf '%s\n' "  git shared-repo-sync \"<message>\"     # pull shared instructions, update parent pointer"
else
  printf '%s\n' "  git shared-repo-sync \"<message>\"     # (alias not registered)"
fi
if has_alias "shared-repo-publish"; then
  printf '%s\n' "  git shared-repo-publish \"<message>\"  # commit & push submodule edits only"
else
  printf '%s\n' "  git shared-repo-publish \"<message>\"  # (alias not registered)"
fi

printf '\n%s\n' "Utility"
if has_alias "shared-repo-update" && has_alias "shared-repo-sync" && has_alias "shared-repo-publish"; then
  printf '%s\n' "  git shared-repo-register-aliases     # aliases already registered"
else
  printf '%s\n' "  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-register-aliases.sh"
fi

printf '%s\n' "  _AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/cli-command-menu.sh"

printf '\n%s\n' "Notes:"
printf '%s\n' "  • Omit the message argument to use the default commit text."
printf '%s\n' "  • Run the alias registration script if any 'alias not registered' messages appear."
