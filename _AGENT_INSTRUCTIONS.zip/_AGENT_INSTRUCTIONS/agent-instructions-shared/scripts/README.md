# Automation Handles

This directory holds executable helpers that bundle repeatable maintenance flows for the shared agent instructions.

| Handle                         | Script                                    | Description                                                                                                                                                       |
| ------------------------------ | ----------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `shared-repo-publish`          | `scripts/shared-repo-publish.sh`          | Stage, commit, and push any pending submodule edits.                                                                                                              |
| `shared-repo-sync`             | `scripts/shared-repo-sync.sh`             | Pull the latest shared instructions, stage the submodule pointer, commit, and push the parent repo (requires a clean submodule).                                  |
| `shared-repo-update`           | `scripts/shared-repo-update.sh`           | Publish pending submodule edits (via `shared-repo-publish`) and then run `shared-repo-sync` with the same message to fast-forward the parent repo pointer safely. |
| `shared-repo-register-aliases` | `scripts/shared-repo-register-aliases.sh` | Configure local `git` aliases (`git shared-repo-update`, etc.) that call the automation scripts without specifying their full paths.                              |
| `cli-command-menu`             | `scripts/cli-command-menu.sh`             | Print a quick reference of available automation commands and their usage, detecting whether aliases are registered.                                               |

## Usage

Run scripts from the parent repository root so the relative paths resolve correctly:

```bash
# Commit/push submodule only
_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-publish.sh "Optional custom commit message"

# Pull latest shared instructions and update parent pointer
_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-sync.sh "Optional custom commit message"

# Publish submodule changes and update parent pointer
_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-update.sh "Optional custom commit message"

# Show a quick reference of available commands
_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/cli-command-menu.sh
```

- The commit message argument is optional; the default is `Update shared agent instructions` for all scripts.
- Scripts exit early if the parent repo has uncommitted work; `shared-repo-update` also self-cleans the submodule before syncing.

## Optional: Git aliases

Run once per clone to expose the scripts as `git` subcommands:

```bash
_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-register-aliases.sh
```

After registration you can run:

```bash
git shared-repo-publish "Adjust shared instructions"
git shared-repo-sync
git shared-repo-update "Sync shared repo"
git cli-command-menu
```

Aliases live in the local `.git/config`, so teammates should rerun the registration script in their own clones if they want the same shortcuts.

Add future handles to the table above to keep the automation catalog in sync with the instructions.
