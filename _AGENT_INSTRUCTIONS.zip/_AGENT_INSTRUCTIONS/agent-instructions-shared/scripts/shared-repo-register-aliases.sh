#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUBMODULE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${SUBMODULE_DIR}/../.." && pwd)"

cd "${REPO_ROOT}"

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "[shared-repo-register-aliases] Error: not inside a Git repository." >&2
  exit 1
fi

if [[ "$(git rev-parse --show-toplevel)" != "${REPO_ROOT}" ]]; then
  echo "[shared-repo-register-aliases] Error: please run the script from the project root." >&2
  exit 1
fi

register_alias() {
  local name="$1"
  local command="$2"
  git config --local "alias.${name}" "!${command}"
  echo "[shared-repo-register-aliases] Registered git alias '${name}'."
}

register_alias "shared-repo-publish" "_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-publish.sh"
register_alias "shared-repo-sync" "_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-sync.sh"
register_alias "shared-repo-update" "_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/shared-repo-update.sh"
register_alias "cli-command-menu" "_AGENT_INSTRUCTIONS/agent-instructions-shared/scripts/cli-command-menu.sh"

cat <<'EOF'
[shared-repo-register-aliases] Aliases available:
  git shared-repo-publish "message"
  git shared-repo-sync "message"
  git shared-repo-update "message"
  git cli-command-menu

The commit message argument is optional for each automation command.
EOF
