---
tier: template
scope: agent
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Agent Prompt — <Task>
## Context
<What the agent needs to know>

## Inputs
<Files, APIs, DBs>

## Steps
1. ...
2. ...

## Output
<Artifacts, code, tests>
