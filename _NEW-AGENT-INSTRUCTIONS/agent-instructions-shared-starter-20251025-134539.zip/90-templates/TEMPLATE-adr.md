---
tier: template
scope: architecture
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# ADR: <Title>

## Status
Accepted | Proposed | Superseded by ADR-XXX

## Context
<Background>

## Decision
<We chose ...>

## Consequences
<Positive/negative tradeoffs>
