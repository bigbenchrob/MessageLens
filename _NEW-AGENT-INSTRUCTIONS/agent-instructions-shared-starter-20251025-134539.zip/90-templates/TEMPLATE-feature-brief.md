---
tier: template
scope: feature
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Feature Brief — <Feature Name>

**Goal**: <What outcome?>

**Scope**: <In/Out>

**Agents**: <Prompts to use>

**Success**: <Measurable checks>
