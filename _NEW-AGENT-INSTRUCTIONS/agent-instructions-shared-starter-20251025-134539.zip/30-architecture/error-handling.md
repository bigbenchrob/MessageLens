---
tier: global
scope: architecture
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Error Handling
- Use `Result<T, Failure>` or `Either`; never throw across layers.
