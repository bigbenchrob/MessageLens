---
tier: global
scope: architecture
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# DDD App Structure (Generic)

Layers:
- **domain/** — entities, value objects, domain services (pure Dart)
- **application/** — use-cases, repositories (interfaces), DTOs
- **infrastructure/** — data sources, repository implementations
- **presentation/** — widgets, state (Riverpod), routes

Rules:
- No inward dependency on infrastructure
- Presentation ↔ application only via providers/use-cases
