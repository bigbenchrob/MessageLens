---
tier: global
scope: architecture
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Feature Modules (Generic)

Each feature:
```
features/<feature>/
  domain/
  application/
  infrastructure/
  presentation/
```
