---
tier: global
scope: flutter
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - flutter test
---

# Theming
- Single ThemeData source; avoid ad-hoc colors in widgets.
