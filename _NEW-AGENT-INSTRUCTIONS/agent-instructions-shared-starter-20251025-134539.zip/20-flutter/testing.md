---
tier: global
scope: testing
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - flutter test --coverage
---

# Testing
- Golden tests for critical UI; smoke tests for flows.
