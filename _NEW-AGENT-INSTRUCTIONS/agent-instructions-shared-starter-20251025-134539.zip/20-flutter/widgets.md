---
tier: global
scope: flutter
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests:
  - flutter test
---

# Widget Guidelines
- Keep widgets small and testable; extract pure functions for logic.
