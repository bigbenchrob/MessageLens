---
tier: global
scope: data
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Sqflite Notes
- Versioned migrations; wrap writes in transactions.
