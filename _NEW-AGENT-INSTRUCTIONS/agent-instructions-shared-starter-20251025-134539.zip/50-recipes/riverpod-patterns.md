---
tier: global
scope: flutter
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Riverpod Patterns
- Families for parameterized reads; keep side-effects in use-cases.
