---
tier: global
scope: performance
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Performance Checklist
- Profile start-up, list builds, and image decoding.
