---
tier: global
scope: flutter
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - dart run build_runner build -d
---

# Riverpod Rules

## ✅ ALWAYS USE CODE GENERATION
- **MANDATORY**: All providers MUST use `@riverpod` annotation
- **NEVER** create manual `StateNotifierProvider` instances
- **REQUIRED**: Include `part 'filename.g.dart';` directive

## ✅ Function Provider Pattern (Recommended)

```dart
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'my_provider.g.dart';

@riverpod
Widget myWidget(Ref ref, int parameter) {
  return Text('Value: $parameter');
}

@riverpod
String myData(Ref ref, String id) => 'Data for $id';
```
