---
tier: global
scope: dart
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - dart analyze
---

# Linting Rules — ENFORCE IMMEDIATELY

- `always_put_control_body_on_new_line` — No single-line if/for/while statements
- `prefer_const_constructors` — Use `const` wherever possible
- `use_colored_box` — Use `ColoredBox` instead of `Container` with only color
- `avoid_void_async` — Async functions must return `Future<void>`
- `directives_ordering` — Sort imports alphabetically
- `unnecessary_brace_in_string_interpolation` — Do not wrap simple identifiers with `${...}`

> Make these effective in `analysis_options.yaml`. Keep this file short; the SoT is the YAML.
