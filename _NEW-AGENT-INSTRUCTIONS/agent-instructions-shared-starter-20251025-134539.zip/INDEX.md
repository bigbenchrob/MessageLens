# Agent Instructions (Shared)

This repository contains reusable, evergreen guidance for Flutter/Dart projects.
Mount this inside each project (submodule or subtree) and keep *project-specific*
details out of here.

**Tiers**
- `00-global/` — rules enforced everywhere (lints, Riverpod conventions)
- `10-language/` — language-specific notes (Dart, SQL, Shell, etc.)
- `20-flutter/` — Flutter-specific patterns, testing, theming
- `30-architecture/` — DDD and layering rules (generic, not per-project)
- `40-tooling/` — analyzer, build_runner, CI/CD
- `50-recipes/` — frequently-used snippets and patterns
- `90-templates/` — markdown templates for ADRs, feature briefs, agent prompts
