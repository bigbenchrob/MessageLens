---
tier: global
scope: tooling
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - dart analyze
  - flutter test
---

# CI/CD
- Analyze, test, build in that order. Fail fast.
