---
tier: global
scope: tooling
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - dart run build_runner build -d
---

# build_runner
- Keep all codegen under one script: `tool/build.sh`
