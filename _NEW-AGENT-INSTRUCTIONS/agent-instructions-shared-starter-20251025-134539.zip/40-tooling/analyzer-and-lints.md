---
tier: global
scope: tooling
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: code
links: []
tests:
  - dart analyze
---

# Analyzer & Lints
- The SoT is `analysis_options.yaml`. This doc links to rationale only.
