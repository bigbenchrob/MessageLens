---
tier: global
scope: tooling
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# Shell Notes
- Prefer small, composable scripts. Keep them in `/tool`.
