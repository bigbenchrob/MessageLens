---
tier: global
scope: sql
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: doc
links: []
tests: []
---

# SQL Notes
- Write idempotent migrations; keep a schema history.
