---
tier: global
scope: dart
owner: @rob
last_reviewed: 2025-10-25
source_of_truth: both
links: []
tests:
  - dart test
---

# Dart Notes
- Prefer `sealed` classes and `switch` expressions where appropriate.
- Avoid dynamic; use generics & `typedef` for terse APIs.
